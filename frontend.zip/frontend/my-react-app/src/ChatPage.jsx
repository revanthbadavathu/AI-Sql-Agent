import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
export default function ChatPage() {

  const navigate = useNavigate();

  const [dbConfig, setDbConfig] = useState({
    host: "",
    port: "",
    username: "",
    password: "",
    database: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setDbConfig((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
  e.preventDefault();
  console.log("FORM SUBMITTED");

  const payload = { ...dbConfig };

  try {
    const response = await fetch("http://localhost:8000/connect-db", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    console.log("STATUS:", response.status);

    if (!response.ok) {
      console.log("NOT OK RESPONSE");
      throw new Error("Failed to connect to DB");
    }

    console.log("ABOUT TO NAVIGATE");
    navigate("/query");

  } catch (error) {
    console.error("ERROR:", error);
    alert("DB Connection Failed");
  }
    // setDbConfig(null);
};


  return (
    <div
   

      style={{
        height: "100vh",
        background: "#1e1e1e",
        color: "white",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: "20px",
        flexDirection: "column"
      }}
    >
      <h2>Connect to Database</h2>
       <button onClick={() => navigate("/query")}>GO</button>
      <form
        onSubmit={handleSubmit}
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "10px",
          background: "#2a2a2a",
          padding: "20px",
          borderRadius: "8px",
          width: "60%",
          maxWidth: "400px"
        }}
      >
        <input
          type="text"
          name="host"
          placeholder="Host (e.g., localhost)"
          value={dbConfig.host}
          onChange={handleChange}
          style={inputStyle}
        />
        <input
          type="text"
          name="port"
          placeholder="Port (e.g., 5432)"
          value={dbConfig.port}
          onChange={handleChange}
          style={inputStyle}
        />
        <input
          type="text"
          name="username"
          placeholder="postgres"
          value={dbConfig.username}
          onChange={handleChange}
          style={inputStyle}
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={dbConfig.password}
          onChange={handleChange}
          style={inputStyle}
        />
        <input
          type="text"
          name="database"
          placeholder="Database Name"
          value={dbConfig.database}
          onChange={handleChange}
          style={inputStyle}
        />

        <button type="submit" style={buttonStyle}>
          Connect
        </button>
      </form>
    </div>
  );
}

// Styles for inputs and button
const inputStyle = {
  padding: "10px",
  borderRadius: "6px",
  border: "none",
  outline: "none"
};

const buttonStyle = {
  padding: "10px 15px",
  borderRadius: "6px",
  border: "none",
  background: "#3a3a3a",
  color: "white",
  cursor: "pointer",
  marginTop: "10px"
};


