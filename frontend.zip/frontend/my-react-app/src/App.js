import { Routes, Route } from "react-router-dom";
import ChatPage from "./ChatPage";
import QueryPage from "./QueryPage";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<ChatPage />} />
      <Route path="/query" element={<QueryPage />} />
    </Routes>
  );
}


