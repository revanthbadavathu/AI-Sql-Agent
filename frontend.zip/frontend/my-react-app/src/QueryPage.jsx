// import { useNavigate } from "react-router-dom";
import React, { useState } from "react";

export default function QueryPage() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState(null);


  const askQuery = async () => {
    const response = await fetch("http://localhost:8000/query", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });
    console.log(response);
    const data = await response.json();
    setResult(data);

  };

  return (
    <div
      style={{
        height: "100vh",
        background: "#1e1e1e",
        color: "white",
        padding: "30px"
      }}
    >
      <h2>Ask Database Anything</h2>

      <textarea
        placeholder="Ask a question like: How many tables are there?"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{
          width: "100%",
          height: "120px",
          padding: "12px",
          borderRadius: "6px"
        }}
      />

      <button
        onClick={askQuery}
        style={{
          marginTop: "10px",
          padding: "10px 20px",
          background: "#e9dbdb",
          border: "none",
          borderRadius: "8px",
          cursor: "pointer"
        }}
      >
        Ask
      </button>

      <div
        style={{
          marginTop: "20px",
          background: "#2a2a2a",
          padding: "15px",
          borderRadius: "8px"
        }}
      >
        {result && (
  <div>
    <h3>SQL:</h3>
    <pre>{result.sql}</pre>

    <h3>Rows:</h3>
    <pre>{JSON.stringify(result.rows, null, 2)}</pre>

    {result.message && (
      <>
        <h3>Message:</h3>
        <p>{result.message}</p>
      </>
    )}
  </div>
)}

      </div>
    </div>
  );
}
