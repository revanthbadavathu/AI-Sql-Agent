from fastapi import FastAPI, Query
from langchain_openai import ChatOpenAI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy import create_engine, text
import os

app = FastAPI()

#globally assigning 
db_engine = None

class DBConfig(BaseModel):
    host: str
    port: str
    username: str
    password: str
    database: str

class QueryRequest(BaseModel):
    query: str

# Set OpenAI API key
os.environ["OPENAI_API_KEY"] = "sk-*****"

origins = [
    "http://localhost:3000",  # your frontend URL
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,        # allow this origin
    allow_credentials=True,
    allow_methods=["*"],          # allow all HTTP methods
    allow_headers=["*"],          # allow all headers
)

# Initialize LLM
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
    api_key=os.getenv("OPENAI_API_KEY")
)

@app.get("/")
async def root():
    return {"message": "Welcome to DB Agent!"}

@app.get("/chat")
async def chat(user_input: str = Query(...)):
    # Directly call LLM
    response = llm.invoke(user_input)
    return {"response": response.content}

@app.post("/connect-db")
def connect_db(config: DBConfig):
    global db_engine

    # Build dynamic PostgreSQL URL
    db_url = f"postgresql://{config.username}:{config.password}@{config.host}:{config.port}/{config.database}"

    # Create storage engine
    try:
        db_engine = create_engine(db_url, echo=True)

        # Test connection
        with db_engine.connect() as conn:
            conn.execute(text("SELECT 1"))

        return {"status": "success", "message": "Connected successfully!"}

    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/query")
async def query(req: QueryRequest):
    global db_engine

    if db_engine is None:
        return {"status": "error", "message": "Database not connected!"}

    try:
        # STEP 1: Extract database schema
        schema_info = ""

        with db_engine.connect() as conn:
            tables = conn.execute(text("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema='public'
            """)).fetchall()

            for table in tables:
                table_name = table[0]

                columns = conn.execute(text(f"""
                    SELECT column_name, data_type 
                    FROM information_schema.columns 
                    WHERE table_name='{table_name}'
                """)).fetchall()

                schema_info += f"\nTable: {table_name}\n"
                for col, dtype in columns:
                    schema_info += f" - {col}: {dtype}\n"

        # STEP 2: Generate SQL using LLM
        prompt = f"""
You are an expert PostgreSQL SQL generator.
Convert the user's question into a valid SELECT query ONLY.

RULES:
- Return ONLY SQL (no explanation, no markdown, no backticks).
- Must be a SELECT query.
- Do NOT use code blocks like ```sql.
- Use the database schema.

--- DATABASE SCHEMA ---
{schema_info}

--- USER QUESTION ---
{req.query}

Return only the raw SQL:
"""

        ai_sql = llm.invoke(prompt).content.strip()

        # Remove accidental markdown fences
        ai_sql = (
            ai_sql.replace("```sql", "")
                  .replace("```", "")
                  .replace("`", "")
                  .strip()
        )

        print("Generated SQL:", ai_sql)

        # STEP 3: Validate (safety filter)
        forbidden = ["update", "delete", "insert", "drop", "alter", ";--"]
        if any(word in ai_sql.lower() for word in forbidden):
            return {
                "status": "error",
                "message": "Unsafe SQL detected! Only SELECT queries allowed.",
                "generated_sql": ai_sql
            }

        # STEP 4: Execute SQL on DB
        with db_engine.connect() as conn:
            result = conn.execute(text(ai_sql)).fetchall()

        # Convert SQLAlchemy Row objects → dict
        rows = [dict(r._mapping) for r in result]

        return {"status": "success",
            "sql": ai_sql,
            "rows": rows
            
        }

    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }

